@extends('layouts.app')

@section('title', 'home')

@section('content')

<div class="container mx-auto min-h-screen pt-5">
    <!-- Encabezado principal con imágenes -->
    <div class="flex items-center justify-center mb-6">
        <img src="{{ asset('images/pyramid.png') }}" alt="Piramide" class="mr-2" style="width: 50px; height: 50px; margin-top: 20px;"> 
        <h1 class="text-5xl text-center text-black pt-4" style="font-family: 'Cinzel', serif; margin-top: 10px;">Bienvenido a Kirbian Books</h1>
        <img src="{{ asset('images/pyramid.png') }}" alt="Piramide" class="ml-2" style="width: 50px; height: 50px; margin-top: 20px;"> 
    </div>

    <!-- Botón para crear nuevo proyecto -->
    <div class="flex justify-end mb-6">
        <a href="{{ route('projects.create') }}" class="btn font-bold py-2 px-4 rounded border border-orange-600" style="background-color: #ED8936; color: black;">
            Crear Nuevo Proyecto
        </a>
    </div>

    <!-- Grid con dos columnas: Tus proyectos y Proyectos de otros usuarios -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
        <!-- Tus proyectos -->
        <section class="bg-yellow-200 p-6 rounded-lg shadow-lg">
            <h2 class="text-2xl text-center mb-4">Tus Proyectos</h2>
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                @foreach($projects as $project)
                <div class="bg-white shadow-lg rounded-lg p-4 flex flex-col justify-between h-full">
                    <div class="flex flex-col justify-center items-center border border-gray-300 p-4 mb-4 h-48 w-full">
                        <h3 class="text-lg font-bold">{{ $project->title }}</h3>
                        <p class="text-gray-500">{{ $project->author }}</p>
                    </div>
                    <div class="flex justify-between mt-auto">
                        <a href="{{ route('projects.edit', $project->id) }}" class="text-blue-500 hover:text-blue-700 border border-blue-500 px-3 py-1 rounded">Editar</a>
                        <a href="{{ route('projects.downloadPdf', $project->id) }}" class="text-gray-500 hover:text-gray-700 border border-gray-500 px-3 py-1 rounded">PDF</a>
                        <a href="#" class="text-red-500 hover:text-red-700 border border-red-500 px-3 py-1 rounded"
                            onclick="if(confirm('¿Estás seguro de que deseas eliminar este proyecto?')) { event.preventDefault(); document.getElementById('delete-project-{{ $project->id }}').submit(); } else { event.preventDefault(); }">
                            Eliminar
                        </a>
                        <form id="delete-project-{{ $project->id }}" action="{{ route('projects.destroy', $project->id) }}" method="POST" style="display: none;">
                            @csrf
                            @method('DELETE')
                        </form>
                    </div>
                </div>
                @endforeach
            </div>
        </section>

        <!-- Proyectos de otros usuarios con fondo naranja fuerte -->
        <section class="p-6 rounded-lg shadow-lg" style="background-color: #ED8936;">
            <h2 class="text-2xl text-center mb-4 text-white">Proyectos de Otros Usuarios</h2>
            <div class="relative w-full overflow-hidden">
                <div class="flex transition-transform duration-300 ease-in-out">
                    @foreach($otherProjects as $project)
                    <div class="w-1/3 p-2">
                        <div class="bg-white shadow-lg rounded-lg p-4 h-full flex flex-col justify-between">
                            <div class="flex flex-col justify-center items-center border border-gray-300 p-4 mb-4 h-48 w-full">
                                <h3 class="text-lg font-bold">{{ $project->title }}</h3>
                                <p class="text-gray-500">{{ $project->author }}</p>
                            </div>
                            <div class="text-center mt-auto">
                                <a href="{{ route('projects.downloadPdf', $project->id) }}" class="text-gray-500 hover:text-gray-700 border border-gray-500 px-3 py-1 rounded">Descargar PDF</a>
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
        </section>

    </div>
</div>

@endsection
