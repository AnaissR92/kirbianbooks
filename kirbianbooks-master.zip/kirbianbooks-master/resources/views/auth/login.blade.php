@extends('layouts.app')

@section('title','Login')

@section('content')

  <div class="block mx-auto my-12 p-8 bg-white w-1/3 border border-gray-200 rounded-lg shadow-lg">
    <h1 class="text-3xl text-center font-bold">Iniciar Sesion</h1>
    <form class="mt-4" method="POST" action="">
      @csrf
      @error('message')
        <p class="border border-red-500 rounded-md bg-red-100w-full text-red-600 p-2 my-2">{{ $message }}</p>    
      @enderror
      <input type="email" class="border border-gray-200 rounded-md bg-gray-200 w-full text-lg placeholder-gray-900 p-2 my-2 focus:bg-white" placeholder="Correo electrónico" id="email" name="email">
      <div class="relative">
          <input type="password" class="border border-gray-200 rounded-md bg-gray-200 w-full text-lg placeholder-gray-900 p-2 my-2 pr-10 focus:bg-white" placeholder="Contraseña" id="login_password" name="password">
          <span class="absolute inset-y-0 right-0 pr-3 flex items-center">
            <i class="fas fa-eye" id="toggleLoginPassword" style="cursor: pointer;"></i>
          </span>
      </div> 
      <button type="submit" class="boton rounded-md w-full text-lg text-white font-semibold p-2 my-3 btn-init">Comenzar</button>
      <p class="mt-4 text-center">¿No tienes cuenta? <a href="{{ route('register.index') }}" class="text-indigo-500 no-underline">Regístrate aquí</a></p>
    </form>
  </div>
    
@endsection