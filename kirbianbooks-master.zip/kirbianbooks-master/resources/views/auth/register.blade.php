@extends('layouts.app')

@section('title','register')

@section('content')

<div class="block mx-auto my-12 p-8 bg-white w-1/3 border border-gray-200 rounded-lg shadow-lg">
  <h1 class="text-3xl text-center font-bold">Registrarse</h1>

  {{-- Mostrar mensajes de error --}}
  @if ($errors->any())
    <div class="mb-4">
      @foreach ($errors->all() as $error)
        <p class="border border-red-500 rounded-md bg-red-100 text-red-600 p-2 my-2">{{ $error }}</p>
      @endforeach
    </div>
  @endif

  @if (session('warning'))
    <p class="border border-orange-500 rounded-md bg-orange-100 text-orange-600 p-2 my-2">{{ session('warning') }}</p>
  @endif

  <form class="mt-4" method="POST" action="{{ route('register.store') }}">
    @csrf
    <input type="text" class="border border-gray-200 rounded-md bg-gray-200 w-full text-lg placeholder-gray-900 p-2 my-2 focus:bg-white" placeholder="Nombre" id="name" name="name" value="{{ old('name') }}">
    
    <input type="email" class="border border-gray-200 rounded-md bg-gray-200 w-full text-lg placeholder-gray-900 p-2 my-2 focus:bg-white" placeholder="Correo electrónico" id="email" name="email" value="{{ old('email') }}">
    
    <div class="relative">
      <input type="password" class="border border-gray-200 rounded-md bg-gray-200 w-full text-lg placeholder-gray-900 p-2 my-2 pr-10 focus:bg-white" placeholder="Contraseña" id="password" name="password">
      <span class="absolute inset-y-0 right-0 pr-3 flex items-center">
        <i class="fas fa-eye" id="togglePassword" style="cursor: pointer;"></i>
      </span>
    </div>

    <div class="relative">
      <input type="password" class="border border-gray-200 rounded-md bg-gray-200 w-full text-lg placeholder-gray-900 p-2 my-2 pr-10 focus:bg-white" placeholder="Confirmar Contraseña" id="password_confirmation" name="password_confirmation">
      <span class="absolute inset-y-0 right-0 pr-3 flex items-center">
        <i class="fas fa-eye" id="togglePasswordConfirmation" style="cursor: pointer;"></i>
      </span>
    </div>

    <button type="submit" class="rounded-md w-full text-lg text-white font-semibold p-2 my-3 btn-init">Registrarse</button>
    <p class="mt-4 text-center">¿Ya tienes cuenta? <a href="{{ route('login.index') }}" class="text-indigo-500 no-underline hover:underline ">Iniciar Sesión</a></p>
  </form>
</div>

@endsection
