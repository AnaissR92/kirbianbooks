<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>@yield('title') - KirbianBooks</title>
        @vite(['resources/js/app.js'])
        <link rel="stylesheet" href="{{ asset('css/styles.css') }}">
        <link href="https://fonts.googleapis.com/css2?family=Audiowide&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.0.1/tailwind.min.css">
        <link href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" rel="stylesheet">
        <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />
<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
    </head>
    <body class="bg-gray-100 text-gray-800"> 
      <nav class=" flex py-3 text-white h-auto" style="background-color: #FF8C00;">
        <div class="w-1/2 px-12 right-12 mr-auto flex items-center" style="color: black;">
            <a href="{{ route('home') }}" class="flex items-center">
                <img src="{{ asset('images/icono.png') }}" alt="Icono Egipcio" class="mr-2" style="width: 50px; height: 50px;"> 
                <p class="text-3xl font-bold italic" style="font-family: 'Audiowide', sans-serif;">KirbianBooks</p>
            </a>
        </div>
        <ul class="w-1/2 px-16 ml-auto flex justify-end items-center">
            @if (auth()->check())
                <li class="mx-6 flex space-x-4">
                    <p class="text-xl text-black">Bienvenido <b>{{ auth()->user()->name }}</b></p>
                </li>
                <li>
                    <a href="{{ route('login.destroy') }}" class="font-bold py-2 px-4 rounded-md bg-red-500 hover:bg-red-600 hover:text-black">Cerrar Sesión</a>
                </li>
            @else
                <li class="mx-6 flex space-x-4">
                    <a href="{{ route('login.index') }}" class="font-semibold border-2 border-white py-2 px-4 rounded-md hover:bg-white hover:text-black">Login</a>
                </li>
                <li>
                    <a href="{{ route('register.index') }}" class="font-semibold border-2 border-white py-2 px-4 rounded-md hover:bg-white hover:text-black">Registrarse</a>
                </li>
            @endif
        </ul>
        </nav>


      @yield('content') 

    </body>

</html>