@extends('layouts.app')

@section('title', isset($project) ? 'Editar Proyecto' : 'Crear Proyecto')

@section('content')

<div class="container mt-5 flex flex-col items-center">
    <div class="bg-white p-6 rounded-lg shadow-lg max-w-2xl w-full" style="background-color: rgba(255, 255, 255, 0.8);">
        <h1 class="text-5xl text-center mb-4" style="font-family: 'Cinzel', serif;">{{ isset($project) ? 'Modificar Proyecto' : 'Nuevo Proyecto' }}</h1> <!-- mb-4 ajustado para reducir el margen inferior -->

        <form action="{{ isset($project) ? route('projects.update', $project->id) : route('projects.store') }}" method="POST" class="w-full">
            @csrf
            @if(isset($project))
                @method('PUT')
            @endif

            <!-- Campo del título y autor centrado -->
            <div class="grid grid-cols-2 gap-4 mb-4"> <!-- Usar grid para organizar mejor los inputs y selects -->
                <div class="form-group">
                    <label for="title" class="form-label">Título del proyecto</label>
                    <input type="text" name="title" class="form-input" value="{{ isset($project) ? $project->title : old('title') }}" required>
                </div>

                <div class="form-group">
                    <label for="author" class="form-label">Autor del proyecto</label>
                    <input type="text" name="author" class="form-input" value="{{ isset($project) ? $project->author : old('author') }}" required>
                </div>
            </div>

            <!-- Select para elegir jeroglíficos y tamaño del libro -->
            <div class="grid grid-cols-2 gap-4 mb-4"> <!-- Usar grid para organizar mejor los selects -->
                <div class="form-group">
                    <label for="hieroglyphs" class="form-label">Inserta un jeroglífico:</label>
                    <select id="hieroglyphs" class="form-select rounded-select" onchange="insertHieroglyph()">
                        <option value="">Selecciona un jeroglífico</option>
                        <option value="𓂀">𓂀 (Ojo de Horus)</option>
                        <option value="𓀀">𓀀 (Hombre)</option>
                        <option value="𓁐">𓁐 (Cara)</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="bookSize" class="form-label">Selecciona el tamaño del libro:</label>
                    <select id="bookSize" class="form-select rounded-select" onchange="changeBookSize()">
                        <option value="">Selecciona el tamaño</option>
                        <option value="book-a5-narrow">Libro A5 (Margen Estrecho)</option>
                        <option value="book-a5-wide">Libro A5 (Margen Ancho)</option>
                        <option value="book-letter-narrow">Libro Carta (Margen Estrecho)</option>
                        <option value="book-letter-wide">Libro Carta (Margen Ancho)</option>
                        <option value="book-legal-narrow">Libro Legal (Margen Estrecho)</option>
                        <option value="book-legal-wide">Libro Legal (Margen Ancho)</option>
                    </select>
                </div>
            </div>

            <!-- Editor CKEditor -->
            <div class="form-group mt-3" style="height: 400px; overflow-y: auto; border: 1px solid #ccc;">
                <label for="content" class="form-label">Contenido del libro</label>
                <textarea id="editor" name="description" class="form-input" style="height: 100%; resize: none;">
                    {{ isset($project) ? $project->description : old('description') }}
                </textarea>
            </div>

            <!-- Botones de acción centrados: Guardar y Volver -->
            <div class="flex justify-between items-center mt-6">
                <a href="{{ route('home') }}" class="btn btn-green">Volver</a>
                <button type="submit" class="btn btn-orange">{{ isset($project) ? 'Actualizar Proyecto' : 'Guardar Proyecto' }}</button>
            </div>
        </form>
    </div>
</div>

<!-- Script CKEditor -->
<script src="https://cdn.ckeditor.com/4.21.0/full/ckeditor.js"></script>
<script>
    // Función para insertar jeroglíficos en el editor
    function insertHieroglyph() {
        var hieroglyph = document.getElementById('hieroglyphs').value;
        if (hieroglyph) {
            CKEDITOR.instances.editor.insertText(hieroglyph);
        }
    }

    // Función para cambiar el tamaño del libro en el editor
    function changeBookSize() {
        var sizeClass = document.getElementById('bookSize').value;
        var editorBody = CKEDITOR.instances.editor.document.getBody();
        
        // Remover clases anteriores
        editorBody.removeClass('book-a5-narrow');
        editorBody.removeClass('book-a5-wide');
        editorBody.removeClass('book-letter-narrow');
        editorBody.removeClass('book-letter-wide');
        editorBody.removeClass('book-legal-narrow');
        editorBody.removeClass('book-legal-wide');
        
        // Agregar la clase seleccionada
        if (sizeClass) {
            editorBody.addClass(sizeClass);
        }
    }

    // Inicialización de CKEditor
    CKEDITOR.replace('editor', {
        extraPlugins: 'justify,font,colorbutton,colordialog,pagebreak',
        removePlugins: 'exportpdf',
        removeButtons: '',
        
        stylesSet: [
            { name: 'Libro A5 (Margen Estrecho)', element: 'div', attributes: { 'class': 'book-a5-narrow' } },
            { name: 'Libro A5 (Margen Ancho)', element: 'div', attributes: { 'class': 'book-a5-wide' } },
            { name: 'Libro Carta (Margen Estrecho)', element: 'div', attributes: { 'class': 'book-letter-narrow' } },
            { name: 'Libro Carta (Margen Ancho)', element: 'div', attributes: { 'class': 'book-letter-wide' } },
            { name: 'Libro Legal (Margen Estrecho)', element: 'div', attributes: { 'class': 'book-legal-narrow' } },
            { name: 'Libro Legal (Margen Ancho)', element: 'div', attributes: { 'class': 'book-legal-wide' } },
            { name: 'Interlineado 0.5', element: 'p', styles: { 'line-height': '0.5' } },
            { name: 'Interlineado 1.2', element: 'p', styles: { 'line-height': '1.2' } },
            { name: 'Interlineado 1.5', element: 'p', styles: { 'line-height': '1.5' } },
            { name: 'Interlineado 2.0', element: 'p', styles: { 'line-height': '2' } }
        ]
    });
</script>

@endsection
