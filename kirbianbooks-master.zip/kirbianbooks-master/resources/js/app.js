document.addEventListener("DOMContentLoaded", function () {
    // contraseña en el registro
    const togglePassword = document.querySelector("#togglePassword");
    const password = document.querySelector("#password");

    if (togglePassword && password) {
        togglePassword.addEventListener("click", function () {
            const type =
                password.getAttribute("type") === "password"
                    ? "text"
                    : "password";
            password.setAttribute("type", type);

            // Cambio en ícono
            this.classList.toggle("fa-eye-slash");
        });
    }

    //confirmación de contraseña en registro
    const togglePasswordConfirmation = document.querySelector(
        "#togglePasswordConfirmation"
    );
    const passwordConfirmation = document.querySelector(
        "#password_confirmation"
    );

    if (togglePasswordConfirmation && passwordConfirmation) {
        togglePasswordConfirmation.addEventListener("click", function () {
            const type =
                passwordConfirmation.getAttribute("type") === "password"
                    ? "text"
                    : "password";
            passwordConfirmation.setAttribute("type", type);

            // Cambio en ícono
            this.classList.toggle("fa-eye-slash");
        });
    }

    //contraseña en el login
    const toggleLoginPassword = document.querySelector("#toggleLoginPassword");
    const loginPassword = document.querySelector("#login_password");

    if (toggleLoginPassword && loginPassword) {
        toggleLoginPassword.addEventListener("click", function () {
            const type =
                loginPassword.getAttribute("type") === "password"
                    ? "text"
                    : "password";
            loginPassword.setAttribute("type", type);

            // Cambiar el ícono entre ojo abierto y cerrado
            this.classList.toggle("fa-eye-slash");
        });
    }
});



