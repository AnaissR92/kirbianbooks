<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Page extends Model
{
    protected $fillable = ['content', 'chapter_id', 'page_number'];

    // Relación con el modelo Chapter
    public function chapter()
    {
        return $this->belongsTo(Chapter::class);
    }
}
