<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Chapter extends Model
{
    protected $fillable = ['title', 'project_id'];

    // Relación con el modelo Project
    public function project()
    {
        return $this->belongsTo(Project::class);
    }

    // Relación con el modelo Page
    public function pages()
    {
        return $this->hasMany(Page::class);
    }
}
