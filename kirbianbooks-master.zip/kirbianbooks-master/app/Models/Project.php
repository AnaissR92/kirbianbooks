<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Project extends Model
{
    use HasFactory;

    // Permitir asignación masiva en estos campos
    protected $fillable = ['title','author', 'description', 'file_path', 'user_id'];

    // Relación con el usuario (un proyecto pertenece a un usuario)
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
