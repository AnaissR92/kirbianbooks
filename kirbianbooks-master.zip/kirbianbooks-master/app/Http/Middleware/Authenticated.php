<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;

class Authenticated
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @param  string|null  $guard
     * @return mixed
     */
    public function handle($request, Closure $next, $guard = null)
    {
        // Verifica si el usuario no está autenticado
        if (Auth::guard($guard)->guest()) {
            // Redirige a la ruta de login si no está autenticado
            return redirect()->route('login.index');
        }

        return $next($request);
    }
}
