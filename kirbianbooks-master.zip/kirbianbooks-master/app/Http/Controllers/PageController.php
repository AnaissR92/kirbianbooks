<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Page;
use App\Models\Chapter;

class PageController extends Controller
{
    public function create($chapterId)
    {
        $chapter = Chapter::findOrFail($chapterId);
        return view('pages.create', compact('chapter'));
    }

    public function store(Request $request, $chapterId)
    {
        // Validar el contenido de la página
        $request->validate([
            'content' => 'required',
        ]);

        // Crear la página dentro del capítulo
        Page::create([
            'content' => $request->content,
            'chapter_id' => $chapterId,
            'page_number' => Page::where('chapter_id', $chapterId)->count() + 1,
        ]);

        return redirect()->route('chapters.show', $chapterId)->with('success', 'Página creada exitosamente.');
    }
}
