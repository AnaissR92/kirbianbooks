<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Project;
use App\Models\Chapter;

class ChapterController extends Controller
{
    public function create($projectId)
    {
        $project = Project::findOrFail($projectId);
        return view('chapters.create', compact('project'));
    }

    public function store(Request $request, $projectId)
    {
        // Validar el título del capítulo
        $request->validate([
            'title' => 'required|string|max:255',
        ]);

        // Crear el capítulo
        $chapter = Chapter::create([
            'title' => $request->title,
            'project_id' => $projectId,
        ]);

        return redirect()->route('projects.show', $projectId)->with('success', 'Capítulo creado exitosamente.');
    }
}
