<?php

namespace App\Http\Controllers;

use App\Models\Project;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth; 
use TCPDF;

class ProjectController extends Controller
{
    
    public function create()
    {
        return view('projects.create');
    }

    // Método que muestra proyectos de user auth
    public function index()
    {
        if (Auth::check()) {
            //projects mios.
            $projects = Project::where('user_id', Auth::id())->get();
            //proyectos de otros users
            $otherProjects = Project::where('user_id', '!=', Auth::id())->get();
            return view('home', compact('projects','otherProjects'));
        } else {
            return redirect()->route('login')->with('error', 'Debes iniciar sesión para ver tus proyectos');
        }
    }

    // Método para guardar un nuevo proyecto
    public function store(Request $request)
    {

        $request->validate([
            'title' => 'required|string|max:255',
            'author' => 'nullable|string|max:255',
            'description' => 'nullable|string',
        ]);


        Project::create([
            'title' => $request->title,
            'author' => $request->author,
            'description' => $request->description,
            'user_id' => Auth::id(),
        ]);
        return redirect()->route('home')->with('success', 'Proyecto creado exitosamente');
    }

    public function show(Project $project)
    {
        return view('projects.show', compact('project'));
    }

    public function edit(Project $project)
    {
        if (Auth::id() !== $project->user_id) {
            return redirect()->route('home')->with('error', 'No tienes permisos para editar este proyecto.');
        }
        return view('projects.create', compact('project'));
    }

    public function update(Request $request, Project $project)
    {
        if (Auth::id() !== $project->user_id) {
            return redirect()->route('home')->with('error', 'No tienes permisos para actualizar este proyecto.');
        }
        $request->validate([
            'title' => 'required|string|max:255',
            'author' => 'nullable|string|max:255',
            'description' => 'nullable|string',
        ]);
        $project->update([
            'title' => $request->title,
            'author' => $request->author,
            'description' => $request->description,
        ]);
        return redirect()->route('home')->with('success', 'Proyecto actualizado exitosamente.');
    }

    //Descargar archivos pdf.
    public function downloadPdf(Project $project)
    {
        $pdf = new TCPDF();

        $pdf->SetTitle('Project ' . $project->title);

        $pdf->AddPage();

        $html = $project->description;
        
        $pdf->writeHTML($html, true, false, true, false, '');

        $pdf->Output('project_' . $project->id . '.pdf', 'D');
    }

    public function destroy(Project $project)
    {
        if (Auth::id() !== $project->user_id) {
            return redirect()->route('home')->with('error', 'No tienes permisos para eliminar este proyecto.');
        }

        $project->delete();

        return redirect()->route('home')->with('success', 'Proyecto eliminado exitosamente.');
    }

    
}
