<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth; //


class SessionsController extends Controller
{
    public function create()
    {

        return view('auth.login');
    }

    public function store() {

        $user = User::where('email', request('email'))->first();

        if (!$user) {
            return back()->withErrors([
                'message' => 'Este email no está registrado.',
            ]);
        }

        if(Auth::attempt(request(['email', 'password'])) == false) {
            return back()->withErrors([
                'message' => 'El email o contraseña son incorrectos, ingresa de nuevo.',
            ]);
        }
        return redirect()->to('/');
    }

    public function destroy() {

        Auth::logout();
        return redirect()->to('/');
    }
}
