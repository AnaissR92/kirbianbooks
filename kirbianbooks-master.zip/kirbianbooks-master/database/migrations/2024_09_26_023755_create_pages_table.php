<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('pages', function (Blueprint $table) {
            $table->id();
            $table->longText('content'); // Contenido de la página
            $table->unsignedBigInteger('chapter_id'); // Relación con el capítulo
            $table->foreign('chapter_id')->references('id')->on('chapters')->onDelete('cascade'); 
            $table->integer('page_number'); // Número de página
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('pages');
    }
};
