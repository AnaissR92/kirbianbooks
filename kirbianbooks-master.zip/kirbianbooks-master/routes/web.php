<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\SessionsController;
use App\Http\Middleware\Authenticated;
use App\Http\Controllers\ProjectController;

Route::middleware([Authenticated::class])->group(function () {
    Route::get('/', function () {
        return view('home');
    })->name('home');
});

Route::get('/register', [RegisterController::class, 'create'])
    ->middleware('guest')
    ->name('register.index');

Route::post('/register', [RegisterController::class, 'store'])
    ->middleware('guest')
    ->name('register.store');

Route::get('/login', [SessionsController::class, 'create'])
    ->middleware('guest')
    ->name('login.index');

Route::post('/login', [SessionsController::class, 'store'])->name('login.store');

Route::get('/logout', [SessionsController::class, 'destroy'])
    ->middleware('auth')
    ->name('login.destroy');

Route::get('/admin', [SessionsController::class, 'index'])
    ->middleware('auth.admin')
    ->name('admin.index');

// Route de Project
//Ruta para listar los proyectos.
Route::middleware([Authenticated::class])->group(function () {
    Route::get('/', [ProjectController::class, 'index'])->name('home');
});

//Ruta para crear un nuevo proyecto.
Route::get('/projects/create', [ProjectController::class, 'create'])
    ->middleware('auth')
    ->name('projects.create');

//Ruta para almacenar.
Route::post('/projects', [ProjectController::class, 'store'])
    ->middleware('auth')
    ->name('projects.store');

//Ruta para editar proyectos.
Route::get('/projects/{project}/edit', [ProjectController::class, 'edit'])
    ->middleware('auth')
    ->name('projects.edit');

//Ruta para actualizar proyectos.
Route::put('/projects/{project}', [ProjectController::class, 'update'])
    ->middleware('auth')
    ->name('projects.update');

//Ruta para el pdf.
Route::get('/projects/{project}/download-pdf', [ProjectController::class, 'downloadPdf'])
    ->middleware('auth')
    ->name('projects.downloadPdf');

//Ruta para Eliminar proyecto
Route::delete('/projects/{project}', [ProjectController::class, 'destroy'])
    ->middleware('auth')
    ->name('projects.destroy');


